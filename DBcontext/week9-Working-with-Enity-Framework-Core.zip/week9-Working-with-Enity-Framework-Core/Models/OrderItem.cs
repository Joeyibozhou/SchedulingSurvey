﻿namespace CIS341_Week9_BookstoreProject.Models
{
    public class OrderItem
    {
        public int OrderItemID { get; set; } // PK
        public int OrderId { get; set; } // FK
        public int BookId { get; set; } // FK
        public int Quantity { get; set; }

        // Navigation properties
        public Order Order { get; set; }
        public Book Book { get; set; }
    }
}
