﻿using System.Collections.Generic;

namespace CIS341_Week9_BookstoreProject.Models
{
    public class ShoppingCart
    {
        public int ShoppingCartID { get; set; } // PK
        public int UserAccountID { get; set; } // FK

        // Navigation properties
        public UserAccount UserAccount { get; set; }
        public ICollection<ShoppingCartItem> Books { get; set; }
    }
}
