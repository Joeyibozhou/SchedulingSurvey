﻿namespace CIS341_Week9_BookstoreProject.Models
{
    public class Book
    {
        public int BookID { get; set; } // PK
        public string Title { get; set; }
        public string Author { get; set; }
        public double Price { get; set; }
        public string Publisher { get; set; }
    }
}
