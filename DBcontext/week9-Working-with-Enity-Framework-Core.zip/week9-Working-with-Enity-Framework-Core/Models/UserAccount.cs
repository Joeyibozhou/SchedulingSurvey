﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace CIS341_Week9_BookstoreProject.Models
{
    public class UserAccount
    {
        public int UserAccountID { get; set; } // PK
        public string FirstName { get; set; }
        public string LastName { get; set; }
        [EmailAddress]
        public string Email { get; set; }
        public string Password { get; set; }

        // Navigation properties
        public ShoppingCart ShoppingCart { get; set; }
        public ICollection<UserAccountOrder> Orders { get; set; }
    }
}
