﻿namespace CIS341_Week9_BookstoreProject.Models
{
    public class ShoppingCartItem
    {
        public int ShoppingCartItemID { get; set; } // PK
        public int ShoppingCartID { get; set; } // FK
        public int BookID { get; set; } // FK
        public int Quantity { get; set; }

        // Navigation properties
        public ShoppingCart ShoppingCart { get; set; }
        public Book Book { get; set; }
    }
}
