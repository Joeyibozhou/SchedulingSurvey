﻿namespace CIS341_Week9_BookstoreProject.Models
{
    public class UserAccountOrder
    {
        public int UserAccountOrderID { get; set; } // PK
        public int UserAccountID { get; set; } // FK
        public int OrderId { get; set; } // FK

        // Navigation properties
        public UserAccount UserAccount { get; set; }
        public Order Order { get; set; }
    }
}
