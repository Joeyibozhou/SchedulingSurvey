﻿using System.Collections.Generic;

namespace CIS341_Week9_BookstoreProject.Models
{
    public class Order
    {
        public int OrderId { get; set; } // PK
        public int UserAccountId { get; set; } // FK
        public double OrderTotal { get; set; }
        public string ShoppingAddress { get; set; }

        // Navigation properties
        public UserAccount UserAccount { get; set; }
        public ICollection<OrderItem> OrderItems { get; set; }
    }
}
