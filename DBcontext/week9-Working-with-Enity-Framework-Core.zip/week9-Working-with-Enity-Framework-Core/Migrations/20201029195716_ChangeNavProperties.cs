﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace CIS341_Week9_BookstoreProject.Migrations
{
    public partial class ChangeNavProperties : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Books_ShoppingCarts_ShoppingCartID",
                table: "Books");

            migrationBuilder.DropIndex(
                name: "IX_Books_ShoppingCartID",
                table: "Books");

            migrationBuilder.DropColumn(
                name: "ShoppingCartID",
                table: "Books");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "ShoppingCartID",
                table: "Books",
                type: "int",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Books_ShoppingCartID",
                table: "Books",
                column: "ShoppingCartID");

            migrationBuilder.AddForeignKey(
                name: "FK_Books_ShoppingCarts_ShoppingCartID",
                table: "Books",
                column: "ShoppingCartID",
                principalTable: "ShoppingCarts",
                principalColumn: "ShoppingCartID",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
