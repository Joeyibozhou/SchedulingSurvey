﻿using CIS341_Week9_BookstoreProject.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CIS341_Week9_BookstoreProject.Data
{
    public static class DbInitializer
    {
        public static void Initialize(BookstoreContext context)
        {
            // Apply pending migrations; create database if it doesn't exist.
            context.Database.Migrate();

            // If we already have content in the DB, exit
            if(context.Books.Count() > 0)
            {
                return;
            }

            Book book = new Book
            {
                Author = "George R. R. Martin",
                Price = 10.99,
                Title = "A Game of Thrones",
                Publisher = "HarperCollins"
            };
            context.Add(book);
            context.SaveChanges();

            UserAccount ua = new UserAccount
            {
                Email = "theimone@uwsp.edu",
                FirstName = "Tomi",
                LastName = "Heimonen",
                Password = "123456",
                Orders = new List<UserAccountOrder>()
            };
            context.Add(ua);
            context.SaveChanges();

            ShoppingCart sc = new ShoppingCart
            {
                UserAccountID = ua.UserAccountID,
                UserAccount = ua,
                Books = new List<ShoppingCartItem>()
            };
            context.Add(sc);
            ua.ShoppingCart = sc;
            context.SaveChanges();
        }
    }
}
